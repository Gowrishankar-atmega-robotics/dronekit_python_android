package com.o3dr.services.android.lib.util;

/**
 * Created by Fredia Huya-Kouadio on 1/19/15.
 */
public class Utils {

    public static final String PACKAGE_NAME = "com.o3dr.services.android";
}
