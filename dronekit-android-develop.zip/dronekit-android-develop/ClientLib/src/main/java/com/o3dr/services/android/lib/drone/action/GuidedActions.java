package com.o3dr.services.android.lib.drone.action;

/**
 * Created by Fredia Huya-Kouadio on 1/19/15.
 */
public class GuidedActions {

    //Private to prevent instantiation
    private GuidedActions(){}

}
