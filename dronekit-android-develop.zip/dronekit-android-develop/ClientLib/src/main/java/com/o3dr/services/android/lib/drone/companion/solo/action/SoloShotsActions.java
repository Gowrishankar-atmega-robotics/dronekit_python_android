package com.o3dr.services.android.lib.drone.companion.solo.action;

/**
 * Created by Fredia Huya-Kouadio on 7/31/15.
 */
public class SoloShotsActions {

    //Private to prevent instantiation
    private SoloShotsActions(){}

    private static final String PACKAGE_NAME = "com.o3dr.services.android.lib.drone.companion.solo.action.shots";
}
