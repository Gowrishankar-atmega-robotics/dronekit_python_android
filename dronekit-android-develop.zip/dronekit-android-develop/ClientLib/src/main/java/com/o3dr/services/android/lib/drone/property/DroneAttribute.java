package com.o3dr.services.android.lib.drone.property;

import android.os.Parcelable;

/**
 * Created by Fredia Huya-Kouadio on 7/27/15.
 */
public interface DroneAttribute extends Parcelable {
}
