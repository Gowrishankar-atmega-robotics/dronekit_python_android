package com.o3dr.android.client.interfaces;

/**
 * Created by fhuya on 11/12/14.
 */
public interface TowerListener {

    void onTowerConnected();

    void onTowerDisconnected();
}
