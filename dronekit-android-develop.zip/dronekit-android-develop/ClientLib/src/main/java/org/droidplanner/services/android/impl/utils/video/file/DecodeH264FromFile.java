package org.droidplanner.services.android.impl.utils.video.file;

import android.view.Surface;

/**
 * Used to decode a h264 elementary stream from a file.
 */
public class DecodeH264FromFile {

    public void playFromFile(Surface surface){

    }
}
