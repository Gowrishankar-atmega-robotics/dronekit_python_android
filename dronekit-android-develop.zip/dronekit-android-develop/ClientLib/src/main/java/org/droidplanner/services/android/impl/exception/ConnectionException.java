package org.droidplanner.services.android.impl.exception;

/**
 * Created by fhuya on 11/2/14.
 */
public class ConnectionException extends Exception {
    public ConnectionException(String s) {
        super(s);
    }
}
