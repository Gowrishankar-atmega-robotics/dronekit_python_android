package org.droidplanner.services.android.impl.utils;

/**
 * Created by Fredia Huya-Kouadio on 2/4/15.
 */
public class Utils {

    public static final String PACKAGE_NAME = "org.droidplanner.services.android";

    private Utils(){}
}
