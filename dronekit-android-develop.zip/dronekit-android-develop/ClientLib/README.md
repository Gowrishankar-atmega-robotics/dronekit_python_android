# DroneKit-Android Client library

#### [Getting started](http://android.dronekit.io/)
#### [Javadocs](http://android.dronekit.io/javadoc/)